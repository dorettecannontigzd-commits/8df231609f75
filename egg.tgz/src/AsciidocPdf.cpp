// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Convert AsciiDoc to PDF"); }
int main(){
  announce();
  return lionss_run_workload("AsciidocPdf");
}

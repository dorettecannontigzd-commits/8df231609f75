// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Floyd-Steinberg dither\n", stdout);
  return lionss_run_workload("dither-floyd");
}

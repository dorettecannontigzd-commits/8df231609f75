// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Relax geometry"); }
int main(){
  announce();
  return lionss_run_workload("dft-relax");
}

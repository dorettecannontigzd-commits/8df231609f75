// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Flash blink image\n", stdout);
  return lionss_run_workload("stm32h7_blink");
}

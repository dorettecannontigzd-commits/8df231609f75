# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(ssao_kernel src/ssao_kernel.cpp)
set_property(TARGET ssao_kernel PROPERTY CXX_STANDARD 11)
target_link_libraries(ssao_kernel lionss pthread)

add_executable(kafkaSink3 src/kafkaSink3.cpp)
set_property(TARGET kafkaSink3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kafkaSink3 lionss pthread)

add_executable(cassandra_repair src/cassandra_repair.cpp)
set_property(TARGET cassandra_repair PROPERTY CXX_STANDARD 11)
target_link_libraries(cassandra_repair lionss pthread)

add_executable(stm32h7_blink src/stm32h7_blink.cpp)
set_property(TARGET stm32h7_blink PROPERTY CXX_STANDARD 11)
target_link_libraries(stm32h7_blink lionss pthread)

add_executable(loraMerge src/loraMerge.cpp)
set_property(TARGET loraMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(loraMerge lionss pthread)

add_executable(renderGraph src/renderGraph.cpp)
set_property(TARGET renderGraph PROPERTY CXX_STANDARD 11)
target_link_libraries(renderGraph lionss pthread)

add_executable(flac_md5 src/flac_md5.cpp)
set_property(TARGET flac_md5 PROPERTY CXX_STANDARD 11)
target_link_libraries(flac_md5 lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(zigComptime src/zigComptime.cpp)
set_property(TARGET zigComptime PROPERTY CXX_STANDARD 11)
target_link_libraries(zigComptime lionss pthread)

add_executable(squall src/squall.cpp)
set_property(TARGET squall PROPERTY CXX_STANDARD 11)
target_link_libraries(squall lionss pthread)

add_executable(ashford src/ashford.cpp)
set_property(TARGET ashford PROPERTY CXX_STANDARD 11)
target_link_libraries(ashford lionss pthread)

add_executable(swift_arc src/swift_arc.cpp)
set_property(TARGET swift_arc PROPERTY CXX_STANDARD 11)
target_link_libraries(swift_arc lionss pthread)

add_executable(verdigris src/verdigris.cpp)
set_property(TARGET verdigris PROPERTY CXX_STANDARD 11)
target_link_libraries(verdigris lionss pthread)

add_executable(spill-tempfile src/spill-tempfile.cpp)
set_property(TARGET spill-tempfile PROPERTY CXX_STANDARD 11)
target_link_libraries(spill-tempfile lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

add_executable(palegold src/palegold.cpp)
set_property(TARGET palegold PROPERTY CXX_STANDARD 11)
target_link_libraries(palegold lionss pthread)

add_executable(mixup-alpha src/mixup-alpha.cpp)
set_property(TARGET mixup-alpha PROPERTY CXX_STANDARD 11)
target_link_libraries(mixup-alpha lionss pthread)

add_executable(dft-relax src/dft-relax.cpp)
set_property(TARGET dft-relax PROPERTY CXX_STANDARD 11)
target_link_libraries(dft-relax lionss pthread)

add_executable(click-remover src/click-remover.cpp)
set_property(TARGET click-remover PROPERTY CXX_STANDARD 11)
target_link_libraries(click-remover lionss pthread)

add_executable(ThistleDown src/ThistleDown.cpp)
set_property(TARGET ThistleDown PROPERTY CXX_STANDARD 11)
target_link_libraries(ThistleDown lionss pthread)

add_executable(blackscholesVega src/blackscholesVega.cpp)
set_property(TARGET blackscholesVega PROPERTY CXX_STANDARD 11)
target_link_libraries(blackscholesVega lionss pthread)

add_executable(OrcBrawlerLOD2 src/OrcBrawlerLOD2.cpp)
set_property(TARGET OrcBrawlerLOD2 PROPERTY CXX_STANDARD 11)
target_link_libraries(OrcBrawlerLOD2 lionss pthread)

add_executable(md_nvt_300k src/md_nvt_300k.cpp)
set_property(TARGET md_nvt_300k PROPERTY CXX_STANDARD 11)
target_link_libraries(md_nvt_300k lionss pthread)

add_executable(HelmholtzSolve src/HelmholtzSolve.cpp)
set_property(TARGET HelmholtzSolve PROPERTY CXX_STANDARD 11)
target_link_libraries(HelmholtzSolve lionss pthread)

add_executable(dither-floyd src/dither-floyd.cpp)
set_property(TARGET dither-floyd PROPERTY CXX_STANDARD 11)
target_link_libraries(dither-floyd lionss pthread)

add_executable(skybox-dawn src/skybox-dawn.cpp)
set_property(TARGET skybox-dawn PROPERTY CXX_STANDARD 11)
target_link_libraries(skybox-dawn lionss pthread)

add_executable(AsciidocPdf src/AsciidocPdf.cpp)
set_property(TARGET AsciidocPdf PROPERTY CXX_STANDARD 11)
target_link_libraries(AsciidocPdf lionss pthread)

add_executable(bleGattNotify src/bleGattNotify.cpp)
set_property(TARGET bleGattNotify PROPERTY CXX_STANDARD 11)
target_link_libraries(bleGattNotify lionss pthread)

add_executable(Cindersmith src/Cindersmith.cpp)
set_property(TARGET Cindersmith PROPERTY CXX_STANDARD 11)
target_link_libraries(Cindersmith lionss pthread)

add_executable(Quillon src/Quillon.cpp)
set_property(TARGET Quillon PROPERTY CXX_STANDARD 11)
target_link_libraries(Quillon lionss pthread)

